package com.playsout.flutter_webgl;

import static android.opengl.EGL14.EGL_CONTEXT_CLIENT_VERSION;
import static android.opengl.EGLExt.EGL_OPENGL_ES3_BIT_KHR;
import static android.opengl.GLES20.GL_NO_ERROR;
import static android.opengl.GLES20.GL_RENDERER;
import static android.opengl.GLES20.GL_VENDOR;
import static android.opengl.GLES20.GL_VERSION;
import static android.opengl.GLES20.glGetError;

import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.GLUtils;
import android.opengl.EGLConfig;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.EGLContext;
import android.opengl.GLES20;
import android.util.Log;
//import javax.microedition.khronos.egl.EGL10;
//import javax.microedition.khronos.egl.EGLConfig;
//import javax.microedition.khronos.egl.EGLContext;
//import javax.microedition.khronos.egl.EGLDisplay;
//import javax.microedition.khronos.egl.EGLSurface;

public final class OpenGLManager {
    private static final String LOG_TAG = "OpenGLManager";
    private EGLDisplay mEglDisplay;
    private EGLContext eglContext;
    private EGLSurface eglSurface;
    private volatile String error;

    EGLConfig eglConfig;
    private int configId;
    /// This here are only used so that we can create surfaces for new textures and access the native
    // handle which is opaque in the Kronos implementation
    private android.opengl.EGLDisplay eglDisplayAndroid;
    private android.opengl.EGLConfig eglConfigAndroid;

    private int mGlVersion = 3;

    public EGLContext getEGLContext() {
        if (eglContext == null) {
            return null;
        }
        return EGL14.eglGetCurrentContext();
    }

    android.opengl.EGLSurface createSurfaceFromTexture(SurfaceTexture texture) {
        int[] attributes = new int[] { EGL14.EGL_NONE };
        android.opengl.EGLSurface eglSurface =  EGL14.eglCreateWindowSurface(
                eglDisplayAndroid,
                eglConfigAndroid,
                texture,
                attributes,
                0
        );
        if (eglSurface == null || eglSurface == EGL14.EGL_NO_SURFACE) {
            error = "Failed to create window surface: " + GLUtils.getEGLErrorString(EGL14.eglGetError());
            Log.e(LOG_TAG, error);
            return null;
        }
        if (!EGL14.eglMakeCurrent(eglDisplayAndroid, eglSurface, eglSurface, eglContext)) {
            error = "Failed to eglMakeCurrent surface: " + GLUtils.getEGLErrorString(EGL14.eglGetError());
            Log.e(LOG_TAG, error);
            return null;
        }
        return eglSurface;
    }

    android.opengl.EGLSurface createDummySurface() {
        int[] surfaceAttributes = new int[] {
                EGL14.EGL_WIDTH, 16,
                EGL14.EGL_HEIGHT, 16,
                EGL14.EGL_NONE,
        };
        return EGL14.eglCreatePbufferSurface(
                eglDisplayAndroid,
                eglConfigAndroid,
                surfaceAttributes,
                0
        );
    }

    boolean initGL() {

        mEglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if (mEglDisplay == EGL14.EGL_NO_DISPLAY) {
            error = "Failed to get EGL display with EGL14";
            return false;
        }
        Log.i(LOG_TAG, "Using EGL14");

        int[] version = new int[2];
        int[] minor = new int[2];
        if (!EGL14.eglInitialize(mEglDisplay, version,0,minor,1)) {
            error = "eglInitialize failed";
            return false;
        }
        Log.i(LOG_TAG, "egl version: " + version[0] + "."+ minor[1] );


        eglConfig = chooseEglConfig();

        if (eglConfig == null) {
            return false;
        }

        eglContext = createContext(mEglDisplay, eglConfig);
        if(eglContext== null){
            Log.e(LOG_TAG, "createContext error: " + EGL14.eglGetError());
            return false;
        }

        int[] surfaceAttributes = new int[] {
                EGL14.EGL_WIDTH,16,
                EGL14.EGL_HEIGHT,16,
                EGL14.EGL_NONE,
        };
        eglSurface = EGL14.eglCreatePbufferSurface(mEglDisplay, eglConfig, surfaceAttributes,0);

        if (eglSurface == null || eglSurface == EGL14.EGL_NO_SURFACE) {
            error = "GL error: " + GLUtils.getEGLErrorString(EGL14.eglGetError());
            return false;
        }

        if (!EGL14.eglMakeCurrent(mEglDisplay, eglSurface, eglSurface, eglContext)) {
            error =
                    "GL make current error: " +
                            GLUtils.getEGLErrorString(EGL14.eglGetError());
            return false;
        }


        // make config and display accessible for EGL14 API because javax.microedition.khronos.egl
        // classes don't allow to access the native handles
        int valA[] = new int[1];
        EGL14.eglGetConfigAttrib(mEglDisplay, eglConfig, EGL14.EGL_CONFIG_ID, valA,0);
        configId = valA[0];

        eglDisplayAndroid = EGL14.eglGetCurrentDisplay();
        int[] attribA = { EGL14.EGL_CONFIG_ID, configId, EGL14.EGL_NONE };
        android.opengl.EGLConfig[] configA = new android.opengl.EGLConfig[1];
        int[] nConfigA = new int[1];
        EGL14.eglChooseConfig(
                eglDisplayAndroid,
                attribA,
                0,
                configA,
                0,
                1,
                nConfigA,
                0
        );
        eglConfigAndroid = configA[0];

        String v = GLES20.glGetString(GL_VENDOR);
        int error = glGetError();
        if (error != GL_NO_ERROR) {
            Log.i(LOG_TAG, "GLError: " + error);
        }
        String r = GLES20.glGetString(GL_RENDERER);
        String v2 = GLES20.glGetString(GL_VERSION);

        Log.i(LOG_TAG,
                "OpenGL initialized: Vendor:" + v + " renderer: " + r + " Version: " + v2
        );
        Log.d(LOG_TAG, "Successfully initialized GL in plugin");

        return true;
    }

    private void deinitGL() {
        EGL14.eglMakeCurrent(
                mEglDisplay,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_CONTEXT
        );
        EGL14.eglDestroySurface(mEglDisplay, eglSurface);
        EGL14.eglDestroyContext(mEglDisplay, eglContext);
        EGL14.eglTerminate(mEglDisplay);
        Log.d(LOG_TAG, "OpenGL deinit OK.");
    }

    private EGLContext createContext(
            EGLDisplay eglDisplay,
            EGLConfig eglConfig
    ) {
        int[] attribList3 = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE };
        int[] attribList2 = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE };
        EGLContext ctx =  EGL14.eglCreateContext(
                eglDisplay,
                eglConfig, EGL14.EGL_NO_CONTEXT,
                attribList3,0
        );
        if(ctx==EGL14.EGL_NO_CONTEXT){
            Log.d(LOG_TAG, "Opengles not support 3.0.");
            ctx =  EGL14.eglCreateContext(
                    eglDisplay,
                    eglConfig, EGL14.EGL_NO_CONTEXT,
                    attribList2,0
            );
            mGlVersion = 2;
        }
        return ctx;
    }

    private EGLConfig chooseEglConfig() {
        int[] configsCount = new int[1];
        EGLConfig[] configs = new EGLConfig[1];
        int[] configSpec = getConfigAttributes();

        if (
                !EGL14.eglChooseConfig(mEglDisplay, configSpec,0, configs,0, 1, configsCount,0)
        ) {
            error =
                    "Failed to choose config: " +
                            GLUtils.getEGLErrorString(EGL14.eglGetError());
            return null;
        } else if (configsCount[0] > 0) {
            int valA[] = new int[1];
            EGL14.eglGetConfigAttrib(mEglDisplay, configs[0], EGL14.EGL_CONFIG_ID, valA,0);
            configId = valA[0];
            return configs[0];
        }

        return null;
    }

    private int[] getConfigAttributes() {
        int renderableType = EGL14.EGL_OPENGL_ES2_BIT;
        if(mGlVersion>=3){
            renderableType |=  EGL_OPENGL_ES3_BIT_KHR;
        }
        return new int[] {
                //EGL14.EGL_COLOR_BUFFER_TYPE, EGL14.EGL_RGB_BUFFER,
                EGL14.EGL_RENDERABLE_TYPE,renderableType,
                EGL14.EGL_SURFACE_TYPE,
                EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_DEPTH_SIZE, 24,
                EGL14.EGL_STENCIL_SIZE, 8,
                EGL14.EGL_NONE,
        };
    /*
    return new int[] {
      EGL10.EGL_RENDERABLE_TYPE,
      EGL_OPENGL_ES3_BIT_KHR,
      EGL_SURFACE_TYPE,
      EGL_WINDOW_BIT,
      EGL10.EGL_RED_SIZE,
      8,
      EGL10.EGL_GREEN_SIZE,
      8,
      EGL10.EGL_BLUE_SIZE,
      8,
      EGL10.EGL_ALPHA_SIZE,
      8,
      EGL10.EGL_DEPTH_SIZE,
      16,
      EGL10.EGL_NONE,
    };
    */
    }

    public String getError() {
        return error;
    }

    public int getConfigId() {
        return configId;
    }

    public android.opengl.EGLDisplay getEglDisplayAndroid() {
        return eglDisplayAndroid;
    }
}
