package com.playsout.flutter_webgl;

import androidx.annotation.NonNull;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;

import io.flutter.view.TextureRegistry;
import java.util.HashMap;
import java.util.Map;

import android.graphics.SurfaceTexture;
import android.os.Build;
import android.util.Log;
import android.opengl.EGL14;
import android.opengl.GLUtils;
import android.opengl.EGL15;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLObjectHandle;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.os.Build;
import android.util.Log;
import android.view.Surface;

import static android.opengl.EGL14.EGL_ALPHA_SIZE;
import static android.opengl.EGL14.EGL_BLUE_SIZE;
import static android.opengl.EGL14.EGL_CONTEXT_CLIENT_VERSION;
import static android.opengl.EGL14.EGL_DEFAULT_DISPLAY;
import static android.opengl.EGL14.EGL_DEPTH_SIZE;
import static android.opengl.EGL14.EGL_GREEN_SIZE;
import static android.opengl.EGL14.EGL_HEIGHT;
import static android.opengl.EGL14.EGL_NONE;
import static android.opengl.EGL14.EGL_NO_CONTEXT;
import static android.opengl.EGL14.EGL_NO_SURFACE;
import static android.opengl.EGL14.EGL_RED_SIZE;
import static android.opengl.EGL14.EGL_RENDERABLE_TYPE;
import static android.opengl.EGL14.EGL_WIDTH;
import static android.opengl.EGL14.eglCreateWindowSurface;
import static android.opengl.EGL14.eglMakeCurrent;
import static android.opengl.EGL15.EGL_OPENGL_ES3_BIT;
import static android.opengl.EGL15.EGL_PLATFORM_ANDROID_KHR;
import static android.opengl.EGLExt.EGL_OPENGL_ES3_BIT_KHR;
import static android.opengl.GLES20.GL_NO_ERROR;
import static android.opengl.GLES20.GL_RENDERER;
import static android.opengl.GLES20.GL_VENDOR;
import static android.opengl.GLES20.GL_VERSION;
import static android.opengl.GLES20.glGetError;

class OpenGLException extends Throwable {

  OpenGLException(String message, int error)
  {
    this.error = error;
    this.message = message;
  }
  int error;
  String message;
};

class AngleCheck {
  public static boolean isEmulator() {
    Log.i("FlutterWebglPlugin", "Using Android Virtual Device.");
    return (Build.FINGERPRINT.startsWith("generic")
      || Build.FINGERPRINT.contains("vbox")
      || Build.FINGERPRINT.contains("sdk_gphone")
      || Build.PRODUCT.contains("sdk")
      || Build.PRODUCT.contains("emulator")
      || Build.PRODUCT.contains("google_sdk")
      || Build.HARDWARE.contains("goldfish")
      || Build.HARDWARE.contains("ranchu")
      || Build.MANUFACTURER.contains("Genymotion")
      || Build.MANUFACTURER.contains("Google")
      || Build.MODEL.contains("google_sdk")
      || Build.MODEL.contains("Emulator")
    );
  }

  public static boolean isVersionAllowed() {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
      Log.i("FlutterWebglPlugin", "Android version is lower than 28.");
      return false;
    }

    Log.i("FlutterWebglPlugin", "Android version is greater than or equal to 28.");
    return true;
  }

  public static boolean isAllowed() {
    if (isEmulator() || !isVersionAllowed()) {
      return false;
    } 
    return true;
  }
}

/** FlutterWebglPlugin */
public class FlutterWebglPlugin implements FlutterPlugin, MethodCallHandler {
  /// The MethodChannel that will the communication between Flutter and native Android
  ///
  /// This local reference serves to register the plugin with the Flutter Engine and unregister it
  /// when the Flutter Engine is detached from the Activity
  private MethodChannel channel;
  private EGLContext context=null;
  private TextureRegistry textureRegistry;
  private OpenGLManager openGLManager;
  private Map<Long,FlutterGLTexture> textureMap;

  private static final String TAG = "FlutterWebglPlugin";

  private static boolean useAngle = false;

  // Load ANGLE native libraries (used by ANGLE methods)
  static {
    try {
      System.loadLibrary("EGL_angle");
      System.loadLibrary("GLESv2_angle");
      System.loadLibrary("angle_android_graphic_jni");
      useAngle = true;
      if(!AngleCheck.isAllowed()){
        useAngle = false;
      }
      Log.i(TAG, "Native ANGLE libraries loaded successfully");
    } catch (UnsatisfiedLinkError e) {
      useAngle = false;
      Log.e(TAG, "Failed to load native ANGLE libraries", e);
    }
  }

  // --- Native methods (used for ANGLE calls) ---
  private static native boolean init();
  private static native void deinit();
  private static native String getError();
  private static native long getCurrentContext();
  private static native long createWindowSurfaceFromTexture(SurfaceTexture texture);
  private static native long createWindowSurfaceFromSurface(Surface surface);

  class FlutterGLTexture
{
  OpenGLManager openGLManager;
  int width;
  int height;
  EGLSurface surface;
  TextureRegistry.SurfaceTextureEntry surfaceTextureEntry;
  public final TextureRegistry.SurfaceProducer surfaceProducer;
  public final boolean usingSurfaceProducer;

  private boolean disposed = false;
  final long surfaceHandle;

  private int[] fbo = new int[1];
  private int[] fboHelp = new int[1];
  int[] rbo = new int[1];
  int[] rboHelp = new int[1];

  public
  FlutterGLTexture(TextureRegistry.SurfaceTextureEntry textureEntry,  OpenGLManager openGLManager, int width, int  height)
  {
    this.width=width;
    this.height=height;
    this.openGLManager = openGLManager;
    surfaceTextureEntry=textureEntry;
    this.usingSurfaceProducer = false;
    this.surfaceProducer = null;
    this.surfaceHandle = 0;

    surfaceTextureEntry.surfaceTexture().setDefaultBufferSize(width,height);
    Log.i("FlutterWebGL", "openGLManager.createSurfaceFromTexture");
    surface = openGLManager.createSurfaceFromTexture(surfaceTextureEntry.surfaceTexture());

    GLES30.glGenFramebuffers(1, fbo, 0);
    GLES30.glGenFramebuffers(1, fboHelp, 0);
    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboHelp[0]);

    GLES30.glGenRenderbuffers(1, rboHelp, 0);
    GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, rboHelp[0]);

    GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_RGBA8, width, height);
    GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_RENDERBUFFER, rboHelp[0]);

    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[0]);

    GLES30.glGenRenderbuffers(1, rbo,0);
    GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, rbo[0]);

    GLES30.glRenderbufferStorageMultisample(GLES30.GL_RENDERBUFFER, 4, GLES30.GL_RGBA8, width, height);
    int error = glGetError();
    if (error != GL_NO_ERROR) {
      Log.e("FlutterWebGL", "GLError: " + error);
    }

    GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_RENDERBUFFER, rbo[0]);

    int frameBufferCheck = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
    if (frameBufferCheck != GLES30.GL_FRAMEBUFFER_COMPLETE) {
      error = glGetError();
      if (error != GL_NO_ERROR) {
        Log.e("FlutterWebGL", "GLError: " + error);
      }
      Log.e("FlutterWebGL", "frameBufferCheck: " + frameBufferCheck);
      //throw new RuntimeException("Framebuffer not complete");
    }
    EGL14.eglMakeCurrent(openGLManager.getEglDisplayAndroid(), EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
  }

  public FlutterGLTexture(
      TextureRegistry.SurfaceProducer producer
    ) {
      this.surfaceProducer = producer;
      this.surfaceTextureEntry = null;
      this.openGLManager = null;
      this.usingSurfaceProducer = true;
      this.width = surfaceProducer.getWidth();
      this.height = surfaceProducer.getHeight();
      this.surfaceHandle = createWindowSurfaceFromSurface(surfaceProducer.getSurface());
      if (this.surfaceHandle == 0) {
        throw new RuntimeException("Failed to create EGL surface: " + getError());
      }
    }

  public FlutterGLTexture(
      TextureRegistry.SurfaceTextureEntry entry, 
      int width, 
      int height
    ) {
      this.surfaceTextureEntry = entry;
      this.surfaceProducer = null;
      this.openGLManager = null;
      this.usingSurfaceProducer = false;
      this.width = width;
      this.height = height;
      surfaceTextureEntry.surfaceTexture().setDefaultBufferSize(width, height);
      this.surfaceHandle = createWindowSurfaceFromTexture(surfaceTextureEntry.surfaceTexture());
      if (this.surfaceHandle == 0) {
        throw new RuntimeException("Failed to create EGL surface: " + getError());
      }
    }

   public long getTextureId() {
      return usingSurfaceProducer ? surfaceProducer.id() : surfaceTextureEntry.id();
    }

  @Override
  protected void finalize() throws Throwable
  {
    if (!disposed) {
      if (usingSurfaceProducer && surfaceProducer != null) {
          surfaceProducer.release();
        } else if (surfaceTextureEntry != null) {
          surfaceTextureEntry.release();
        }

      if(openGLManager!=null){
      // 销毁帧缓冲对象
      GLES30.glDeleteFramebuffers(1, fbo, 0);
      GLES30.glDeleteRenderbuffers(1, rbo, 0);

      GLES30.glDeleteFramebuffers(1, fboHelp, 0);
      GLES30.glDeleteRenderbuffers(1, rboHelp, 0);

      //surfaceTextureEntry.release();
      EGL14.eglDestroySurface(openGLManager.getEglDisplayAndroid(), surface);
      }
      disposed = true;
    }

    super.finalize();

  }

};

  @Override
  public void onAttachedToEngine(@NonNull FlutterPluginBinding flutterPluginBinding) {
    channel = new MethodChannel(flutterPluginBinding.getBinaryMessenger(), "flutter_webgl");
    channel.setMethodCallHandler(this);
    textureRegistry = flutterPluginBinding.getTextureRegistry();
    textureMap = new HashMap<>();
  }

  @Override
  public void onMethodCall(@NonNull MethodCall call, @NonNull Result result) {
    Map<String, Object> arguments = (Map<String, Object>) call.arguments;
    if (call.method.equals("getPlatformVersion")) {
      result.success("Android " + android.os.Build.VERSION.RELEASE);
       } else if (call.method.equals("initOpenGL")) {
      if(!useAngle){
        initOpenGLImplementation(result);
      }else{
        initOpenGLAngleImplementation(result);
      }
    }
    else if (call.method.equals("createTexture")) {
      if(!useAngle){
      createOpenGLTextureImplementation(call, result);
      }else{
        createTextureAngleImplementation(call, result);
      }

    } else if(call.method.equals("deleteTexture")){
      int id = (int) arguments.get("textureId");
      textureMap.remove(id);
      Map<String, Object> response = new HashMap<>();
      result.success(response);
    } else {
      result.notImplemented();
    }
  }

  @Override
  public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
    channel.setMethodCallHandler(null);
  }

  private void initOpenGLImplementation(MethodChannel.Result result) {
    if (context != null) {
        // TODO this isn't fully handled on the dart side yet
        // this means initOpenGL() was already called, which makes sense if you want to access a Texture not only
        // from the main thread but also from an isolate. On the plugin layer here that doesn't bother because all
        // by `initOpenGL``in Dart created contexts will be linked to the one we got from the very first call to `initOpenGL`
        // we return this information so that the Dart side can dispose of one context.
        long handle = context.getNativeHandle();
        result.success(handle);

        return;
      }
      openGLManager = new OpenGLManager();

      if(!openGLManager.initGL())
      {
        result.error("OpenGL Init Error",openGLManager.getError(),null);
        return;
      }

      context = openGLManager.getEGLContext();
      /*
      Log.i("FlutterWebglPlugin", "openGLManager.getEGLContext");
      TextureRegistry.SurfaceTextureEntry surfaceTextureEntry = textureRegistry.createSurfaceTexture();
      Log.i("FlutterWebglPlugin", "createSurfaceTexture");
      SurfaceTexture surfaceTexture = surfaceTextureEntry.surfaceTexture();
      //Log.i("FlutterWebglPlugin", "surfaceTexture");
      surfaceTexture.setDefaultBufferSize(411,866);
      Log.i("FlutterWebglPlugin", "before openGLManager.createSurfaceFromTexture");
      long surface = openGLManager.createSurfaceFromTexture(surfaceTexture).getNativeHandle();
      Log.i("FlutterWebglPlugin", "openGLManager.createSurfaceFromTexture");
      */

      Map<String, Object> response = new HashMap<>();
      response.put("context", context.getNativeHandle());
      response.put("eglConfigId",openGLManager.getConfigId());
      response.put("useAngle", false);
      //response.put("dummySurface",surface );
      // response.put("dummySurface",openGLManager.createDummySurface().getNativeHandle());
      result.success(response);
  }

  private void initOpenGLAngleImplementation(MethodChannel.Result result) {
    // Plugin2: using native ANGLE functions
    if (!init()) {
      String error = getError();
      Log.e(TAG, "ANGLE init failed: " + error);
      result.error("OpenGL Init Error", error, null);
      return;
    }

    Map<String, Object> response = new HashMap<>();
    response.put("useAngle", true);
    result.success(response);

    Log.i(TAG, "ANGLE OpenGL initialized successfully");
  }

  private void createOpenGLTextureImplementation(MethodCall call, MethodChannel.Result result) {
     Map<String, Object> arguments = (Map<String, Object>) call.arguments;
    int width = (int) arguments.get("width");
      int height = (int) arguments.get("height");

      if (width == 0) {
        result.error("no texture width", "no texture width", 0);
        return;
      }
      if (height == 0) {
        result.error("no texture height", "no texture height", null);
        return;
      }
      FlutterGLTexture flutterGLTexture;

      try {
        int error = glGetError();
        if (error != GL_NO_ERROR) {
          Log.i("FlutterWebGL", "GLError: " + error);
        }
        Log.i("FlutterWebGL", "textureRegistry.createSurfaceTexture");
        TextureRegistry.SurfaceTextureEntry surfaceTextureEntry = textureRegistry.createSurfaceTexture();
        error = glGetError();
        if (error != GL_NO_ERROR) {
          Log.i("FlutterWebGL", "GLError: " + error);
        }
        String error_str = "create window surface: " + GLUtils.getEGLErrorString(error);
        Log.i("FlutterWebGL", error_str);
        Log.i("FlutterWebGL", "new FlutterGLTexture");
        flutterGLTexture = new FlutterGLTexture(surfaceTextureEntry, openGLManager, width, height);
      } catch (Exception ex) {
        result.error(ex.getMessage() + " : " + ex.toString(), null, null);
        return;
      }
      textureMap.put(flutterGLTexture.surfaceTextureEntry.id(), flutterGLTexture);


      Map<String, Object> response = new HashMap<>();
      response.put("textureId", flutterGLTexture.surfaceTextureEntry.id());
      response.put("surface", flutterGLTexture.surface.getNativeHandle());
      response.put("rbo", flutterGLTexture.rbo[0]);
      response.put("rbohelp", flutterGLTexture.rboHelp[0]);
      result.success(response);

      Log.i("FlutterWebGL", "Created a new texture " + width + "x" + height);
  }

  private void createTextureAngleImplementation(MethodCall call, MethodChannel.Result result) {
    try {
      @SuppressWarnings("unchecked")
      Map<String, Object> args = (Map<String, Object>) call.arguments;
      int width = (int) args.get("width");
      int height = (int) args.get("height");
      //boolean useSurfaceProducer = (boolean) args.get("useSurfaceProducer");
      boolean useSurfaceProducer = false;
      if (width <= 0 || height <= 0) {
        result.error("Invalid dimensions", "Width and height must be positive", null);
        return;
      }
      
      FlutterGLTexture texture;
      if (useSurfaceProducer) {
        try {
          // Use the new API
          TextureRegistry.SurfaceProducer producer = textureRegistry.createSurfaceProducer();
          producer.setSize(width, height);
          texture = new FlutterGLTexture(producer);
          Log.i(TAG, "Created ANGLE texture using SurfaceProducer API");
        } catch (Exception e) {
          // Fall back to old API if SurfaceProducer fails
          Log.w(TAG, "SurfaceProducer failed, falling back to SurfaceTextureEntry", e);
          TextureRegistry.SurfaceTextureEntry entry = textureRegistry.createSurfaceTexture();
          texture = new FlutterGLTexture(entry, width, height);
          Log.i(TAG, "Created ANGLE texture using SurfaceTextureEntry API (fallback)");
        }
      } else {
        // Explicitly use old API
        TextureRegistry.SurfaceTextureEntry entry = textureRegistry.createSurfaceTexture();
        texture = new FlutterGLTexture(entry, width, height);
        Log.i(TAG, "Created ANGLE texture using SurfaceTextureEntry API (legacy)");
      }
      
      textureMap.put(texture.getTextureId(), texture);

      Map<String, Object> response = new HashMap<>();
      response.put("textureId", texture.getTextureId());
      response.put("surface", texture.surfaceHandle);
      result.success(response);

      Log.i(TAG, String.format("Created ANGLE texture %dx%d", width, height));
    } catch (Exception e) {
      Log.e(TAG, "ANGLE texture creation failed", e);
      result.error("Texture creation failed", e.getMessage(), null);
    }
  }

}
